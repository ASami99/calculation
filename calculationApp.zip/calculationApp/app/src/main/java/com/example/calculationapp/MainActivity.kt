package com.example.calculationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var editText1: EditText
    private lateinit var editText2: EditText
    private lateinit var calculateButton: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Link the variables to the views in the layout file
        editText1 = findViewById(R.id.editText1)
        editText2 = findViewById(R.id.editText2)
        calculateButton = findViewById(R.id.calculateButton)

        // Set an OnClickListener on the Button

        calculateButton.setOnClickListener {
            // Get the values from the EditText views
            val value1 = editText1.text.toString().toDouble()
            val value2 = editText2.text.toString().toDouble()

            // Calculate the result
            val result = value1 + value2

            // Create an Intent to navigate to the second screen

            val intent = Intent(this, SecondScreenActivity::class.java)
            // Pass the values to the second screen using the Intent

             intent.putExtra("value1", value1)
             intent.putExtra("value2", value2)
            intent.putExtra("result", result)

            // Start the second activity
            startActivity(intent)
        }
    }
}

class SecondScreenActivity : AppCompatActivity(){

    private lateinit var resultTextView: TextView
    private lateinit var addtocart: Button
    private lateinit var priceredmi: TextView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.secondscreen)

        // Link the variable to the view in the layout file
        resultTextView = findViewById(R.id.resultTextView)
        val value1 = intent.getDoubleExtra("value1", 0.0)
        val value2 = intent.getDoubleExtra("value2", 0.0)
        val result = intent.getDoubleExtra("result", 0.0)

        // Display the result on the screen
        resultTextView.text = "$value1   *   $value2 = $result"


//    add to cart functions

        addtocart = findViewById(R.id.redmibtn)
        addtocart.setOnClickListener{
        priceredmi = findViewById(R.id.priceredmi)
            val price = priceredmi.text.toString().toDouble()

            val thirdintent = Intent(this, SecondScreenActivity::class.java)


        }
    }
}


